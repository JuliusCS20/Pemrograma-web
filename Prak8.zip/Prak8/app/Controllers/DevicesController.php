<?php

namespace App\Controllers;

class DevicesController extends BaseController
{
    public function devicestable()
    {
        return view('page/devices');
    }
}