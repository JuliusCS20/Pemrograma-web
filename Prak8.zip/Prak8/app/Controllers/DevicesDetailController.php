<?php

namespace App\Controllers;

class DevicesDetailController extends BaseController
{
    public function devicesdetail()
    {
        return view('page/devicedetail');
    }
    public function devicesdetail2()
    {
        return view('page/devicedetail2');
    }
    public function devicesdetail3()
    {
        return view('page/devicedetail3');
    }
    public function devicesdetail4()
    {
        return view('page/devicedetail4');
    }
    public function devicesdetail5()
    {
        return view('page/devicedetail5');
    }
}