<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Device IoT</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">IoT Monitoring</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Devices</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Device Detail</a>
      </li>
    </ul>
  </div>
</nav>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Gambar</th>
      <th scope="col">Device_name</th>
      <th scope="col">Merk</th>
      <th scope="col">Jumlah</th>
      <th scope="col">Status</th>
      <th scope="col">Aksi</th>

    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><img src="img/arduino.png" width = "300" height = "200" alt="Arduino"></td>
      <td>Arduino Uno</td>
      <td>Arduino</td>
      <td>900</td>
      <td>1</td>
      <td><a href="/Prak8/public/devicesdetail"><button>Detail</button></a></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td><img src="img/cctv.jpg" width = "300" height = "200" alt="Arduino"></td>
      <td>CCTV Aquarius Smart Camera</td>
      <td>Aquarius</td>
      <td>904</td>
      <td>1</td>
      <td><a href="/Prak8/public/devicesdetail2"><button>Detail</button></a></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td><img src="img/proyektor.jpg" width = "300" height = "200" alt="Arduino"></td>
      <td>Proyektor VPL-VW590ES Noir</td>
      <td>Sony</td>
      <td>100</td>
      <td>0</td>
      <td><a href="/Prak8/public/devicesdetail3"><button>Detail</button></a></td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td><img src="img/smartdoor.jpg" width = "300" height = "200" alt="Arduino"></td>
      <td>Smartdoor SHS-H505 USA Version</td>
      <td>Samsung</td>
      <td>98</td>
      <td>0</td>
      <td><a href="/Prak8/public/devicesdetail4"><button>Detail</button></a></td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td><img src="img/smarttv.jpg" width = "300" height = "200" alt="Arduino"></td>
      <td>Smart TV 55' UE55AU7100 Smart 4K Crystal UHD HDR</td>
      <td>Samsung</td>
      <td>10</td>
      <td>1</td>
      <td><a href="/Prak8/public/devicesdetail5"><button>Detail</button></a></td>
    </tr>
  </tbody>
</table>
</body>
</html>